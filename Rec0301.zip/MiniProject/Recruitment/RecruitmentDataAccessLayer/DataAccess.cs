﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecruitmentExceptions;
using RecruitmentEntities;
using System.Data.Common;
using System.Data;

namespace RecruitmentDataAccessLayer
{
    public class DataAccess
    {
        public string authenticateUserDAL(string username, string password)
        {
            string utype = null;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select user_type from Login_Credentials where email_id='"+username+"' and user_password='"+password+"';";

                DataTable dt = DataConnection.ExecuteSelectCommand(command);
                if (dt.Rows.Count > 0)
                {
                    utype = (string)dt.Rows[0][0];
                }
                return utype;
            }
            catch(Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }

        public string getcnameDAL(string email)
        {
            string company = null;
            try
            {
                DbCommand com = DataConnection.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select company_name from employer_details where email_id='" + email + "';";

                DataTable dt = DataConnection.ExecuteSelectCommand(com);
                if (dt.Rows.Count > 0)
                {
                    company = (string)dt.Rows[0][0];
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return company;
        }

        public bool addJobSeekerDAL(JobSeeker jsObj)
        {
            bool jobSeekeradded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "addJobSeeker";

                DbParameter param = command.CreateParameter();

                param.ParameterName = "@email_id";
                param.DbType = DbType.String;
                param.Value = jsObj.JS_EMAILID;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@fname";
                param.DbType = DbType.String;
                param.Value = jsObj.FIRSTNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@lname";
                param.DbType = DbType.String;
                param.Value = jsObj.LASTNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@dob";
                param.DbType = DbType.DateTime;
                param.Value = jsObj.DOB.Date;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@mobile_no";
                param.DbType = DbType.Int64;
                param.Value = jsObj.JS_CONTACT;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@photo";
                param.DbType = DbType.String;
                param.Value = jsObj.PHOTO;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@hsc_board";
                param.DbType = DbType.String;
                param.Value = jsObj.HSC_BOARD;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@hsc_percentage";
                param.DbType = DbType.Decimal;
                param.Value = jsObj.HSC_PERCENTAGE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@hsc_yop";
                param.DbType = DbType.Int32;
                param.Value = jsObj.HSC_YOP;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ssc_board";
                param.DbType = DbType.String;
                param.Value = jsObj.SSC_BOARD;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ssc_percentage";
                param.DbType = DbType.Decimal;
                param.Value = jsObj.SSC_PERCENTAGE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ssc_yop";
                param.DbType = DbType.Int32;
                param.Value = jsObj.SSC_YOP;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ug_university";
                param.DbType = DbType.String;
                param.Value = jsObj.UG_UNIVERSITY;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ug_percentage";
                param.DbType = DbType.Decimal;
                param.Value = jsObj.UG_PERCENTAGE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ug_yop";
                param.DbType = DbType.Int32;
                param.Value = jsObj.UG_YOP;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@experience";
                param.DbType = DbType.Int32;
                param.Value = jsObj.JS_EXPERIENCE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@skills";
                param.DbType = DbType.String;
                param.Value = jsObj.JS_SKILLS;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@resume";
                param.DbType = DbType.String;
                param.Value = jsObj.RESUME;
                command.Parameters.Add(param);

                int affectedrows = DataConnection.ExecuteNonQueryCommand(command);
                if (affectedrows > 0)
                    jobSeekeradded = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jobSeekeradded;
        }

        public List<Job> searchJobsDAL(string searchText, string searchParam)
        {
            List<Job> searchedJobs = new List<Job>();
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from Job_details where "+searchParam+"='"+searchText+"';";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@searchText";
                param.DbType = DbType.String;
                param.Value = searchText;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@searchParam";
                param.DbType = DbType.String;
                param.Value = searchParam;
                command.Parameters.Add(param);

                DataTable dt = DataConnection.ExecuteSelectCommand(command);
                
                if (dt.Rows.Count>0)
                {
                    Job newJob = new Job();

                    for(int index=0;index<dt.Rows.Count;index++)
                    {
                        newJob.JOB_COMPANYNAME = Convert.ToString(dt.Rows[index][0]);
                        newJob.JOBID = Convert.ToInt32(dt.Rows[index][1]);
                        newJob.JOB_CATEGORY = Convert.ToString(dt.Rows[index][2]);
                        newJob.JOB_SKILLS = Convert.ToString(dt.Rows[index][3]);
                        newJob.DESIGNATION = Convert.ToString(dt.Rows[index][4]);
                        newJob.JOB_LOCATION = Convert.ToString(dt.Rows[index][5]);
                        newJob.JOB_EXPERIENCE = Convert.ToInt32(dt.Rows[index][6]);
                        newJob.NO_OF_POSITIONS = Convert.ToInt32(dt.Rows[index][7]);
                        
                        searchedJobs.Add(newJob);
                    }
                }
                return searchedJobs;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool addJobDAL(Job job)
        {
            bool jobAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "addJob";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@companyname";
                param.DbType = DbType.String;
                param.Value = job.JOB_COMPANYNAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@category";
                param.DbType = DbType.String;
                param.Value = job.JOB_CATEGORY;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@skills";
                param.DbType = DbType.String;
                param.Value = job.JOB_SKILLS;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@designation";
                param.DbType = DbType.String;
                param.Value = job.DESIGNATION;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@location";
                param.DbType = DbType.String;
                param.Value = job.JOB_LOCATION;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@exp";
                param.DbType = DbType.Int16;
                param.Value = job.JOB_EXPERIENCE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@openings";
                param.DbType = DbType.Int32;
                param.Value = job.NO_OF_POSITIONS;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    jobAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new RecruitmentException(errormessage);
            }
            return jobAdded;
        }

        //public int getJobIdDAL()
        //{
        //    int id = 0;
        //    try
        //    {
        //        DbCommand com = DataConnection.CreateCommand();
        //        com.CommandText = "getJobId";

        //        DbParameter param = com.CreateParameter();
        //        param.ParameterName = "@jobId";
        //        param.DbType = DbType.Int32;
        //        param.Direction = ParameterDirection.Output;
        //        com.Parameters.Add(param);

        //        DataTable dt = new DataTable();
        //        dt=DataConnection.ExecuteSelectCommand(com);
        //        if(dt.Rows.Count>0)
        //        {
        //            string dvalue = (string)dt.Rows[0][0];
        //            if (dvalue.Equals("NULL"))
        //                id = 0;
        //        }
        //        id = Convert.ToInt32(param.Value);

        //    }
        //    catch(Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return id+1;
        //}

        public bool AddEmployerDAL(Employer employer)
        {
            bool employerAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspAddEmployer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@EmailID";
                param.DbType = DbType.String;
                param.Value = employer.EMP_EMAILID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@CompanyName";
                param.DbType = DbType.String;
                param.Value = employer.EMP_COMPANYNAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@CompanyInfo";
                param.DbType = DbType.String;
                param.Value = employer.COMPANYINFO;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Client";
                param.DbType = DbType.String;
                param.Value = employer.CLIENT;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@EmpContact";
                param.DbType = DbType.Decimal;
                param.Value = employer.EMP_CONTACT;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Website";
                param.DbType = DbType.String;
                param.Value = employer.WEBSITE;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    employerAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new RecruitmentException(errormessage);
            }
            return employerAdded;
        }

        public bool addUserDAL(string username, string password, string user_type)
        {
            bool useradded = false;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "addUser";

                DbParameter param = command.CreateParameter();

                param.ParameterName = "@username";
                param.DbType = DbType.String;
                param.Value = username;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@password";
                param.DbType = DbType.String;
                param.Value = password;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@usertype";
                param.DbType = DbType.String;
                param.Value = user_type;
                command.Parameters.Add(param);

                int affectedrows = DataConnection.ExecuteNonQueryCommand(command);
                if (affectedrows > 0)
                    useradded = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return useradded;
        }
    }
}

