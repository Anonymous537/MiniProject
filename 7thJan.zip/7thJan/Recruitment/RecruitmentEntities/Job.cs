﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecruitmentEntities
{
    public class Job
    {
        public string JOB_COMPANYNAME { get; set; }
        public int JOBID { get; set; }
        public string JOB_CATEGORY { get; set; }
        public string JOB_SKILLS { get; set; }
        public string DESIGNATION { get; set; }
        public string JOB_LOCATION { get; set; }
        public int JOB_EXPERIENCE { get; set; }
        public int NO_OF_POSITIONS { get; set; }
    }
}
