﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecruitmentExceptions;
using RecruitmentEntities;
using System.Data.Common;
using System.Data;

namespace RecruitmentDataAccessLayer
{
    public class DataAccess
    {
        public string authenticateUserDAL(string username, string password)
        {
            string utype = null;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select user_type from Login_Credentials where email_id='"+username+"' and user_password='"+password+"';";

                DataTable dt = DataConnection.ExecuteSelectCommand(command);
                if (dt.Rows.Count > 0)
                {
                    utype = (string)dt.Rows[0][0];
                }
                return utype;
            }
            catch(Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }

        public bool addJobSeekerDAL(JobSeeker jsObj)
        {
            bool jobSeekeradded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "addJobSeeker";

                DbParameter param = command.CreateParameter();

                param.ParameterName = "@email_id";
                param.DbType = DbType.String;
                param.Value = jsObj.JS_EMAILID;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@fname";
                param.DbType = DbType.String;
                param.Value = jsObj.FIRSTNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@lname";
                param.DbType = DbType.String;
                param.Value = jsObj.LASTNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@dob";
                param.DbType = DbType.DateTime;
                param.Value = jsObj.DOB.Date;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@mobile_no";
                param.DbType = DbType.Int64;
                param.Value = jsObj.JS_CONTACT;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@photo";
                param.DbType = DbType.String;
                param.Value = jsObj.PHOTO;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@hsc_board";
                param.DbType = DbType.String;
                param.Value = jsObj.HSC_BOARD;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@hsc_percentage";
                param.DbType = DbType.Decimal;
                param.Value = jsObj.HSC_PERCENTAGE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@hsc_yop";
                param.DbType = DbType.Int32;
                param.Value = jsObj.HSC_YOP;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ssc_board";
                param.DbType = DbType.String;
                param.Value = jsObj.SSC_BOARD;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ssc_percentage";
                param.DbType = DbType.Decimal;
                param.Value = jsObj.SSC_PERCENTAGE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ssc_yop";
                param.DbType = DbType.Int32;
                param.Value = jsObj.SSC_YOP;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ug_university";
                param.DbType = DbType.String;
                param.Value = jsObj.UG_UNIVERSITY;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ug_percentage";
                param.DbType = DbType.Decimal;
                param.Value = jsObj.UG_PERCENTAGE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ug_yop";
                param.DbType = DbType.Int32;
                param.Value = jsObj.UG_YOP;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@experience";
                param.DbType = DbType.Int32;
                param.Value = jsObj.JS_EXPERIENCE;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@skills";
                param.DbType = DbType.String;
                param.Value = jsObj.JS_SKILLS;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@resume";
                param.DbType = DbType.String;
                param.Value = jsObj.RESUME;
                command.Parameters.Add(param);

                int affectedrows = DataConnection.ExecuteNonQueryCommand(command);
                if (affectedrows > 0)
                    jobSeekeradded = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return jobSeekeradded;
        }

        public bool addUserDAL(string username, string password, string user_type)
        {
            bool useradded = false;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "addUser";

                DbParameter param = command.CreateParameter();

                param.ParameterName = "@username";
                param.DbType = DbType.String;
                param.Value = username;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@password";
                param.DbType = DbType.String;
                param.Value = password;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@usertype";
                param.DbType = DbType.String;
                param.Value = user_type;
                command.Parameters.Add(param);

                int affectedrows = DataConnection.ExecuteNonQueryCommand(command);
                if (affectedrows > 0)
                    useradded = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return useradded;
        }
    }
}

