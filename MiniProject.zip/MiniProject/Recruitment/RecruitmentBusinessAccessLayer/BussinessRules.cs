﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecruitmentDataAccessLayer;


namespace RecruitmentBusinessAccessLayer
{
    public class BussinessRules
    {
        public string authenticateUser(string username, string password)
        {
            DataAccess dalobj = new DataAccess();
            return dalobj.authenticateUserDAL(username, password);

        }
    }
}
