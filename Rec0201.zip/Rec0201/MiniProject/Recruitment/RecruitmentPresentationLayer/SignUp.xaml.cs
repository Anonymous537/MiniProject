﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using RecruitmentEntities;
using RecruitmentBusinessAccessLayer;
using RecruitmentExceptions;


namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for SignUp.xaml
    /// </summary>
    public partial class SignUp : Window
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string username = txtEmail.Text;
                string password = txtPassword.Password;
                string confpassword = txtPasswordConf.Password;
                string utype = null;
                if (radioJobseeker.IsChecked == true)
                    utype = "jobseeker";
                else
                    utype = "employer";
                bool status = false;
                BussinessRules balObj = new BussinessRules();
                if (password == confpassword)
                {
                    status = balObj.addUser(username, password, utype);
                    if (status)
                    {
                        MessageBox.Show("User added successfully.\n Login to continue");
                        MainWindow mainObj = new MainWindow();
                        mainObj.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("User not added");
                    }
                }

                else
                    MessageBox.Show("Passwords do not match.", "Invalid password", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch(RecruitmentException ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
