﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecruitmentDataAccessLayer;
using RecruitmentExceptions;
using RecruitmentEntities;

namespace RecruitmentBusinessAccessLayer
{
    public class BussinessRules
    {
        public string authenticateUser(string username, string password)
        {
            DataAccess dalobj = new DataAccess();
            return dalobj.authenticateUserDAL(username, password);

        }

        public bool addUser(string username, string password, string user_type)
        {
            try
            {
                DataAccess dalobj = new DataAccess();
                return dalobj.addUserDAL(username, password, user_type);
            }
            catch(Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }
        public bool addJobSeeker(JobSeeker jsObj)
        {
            try
            {
                DataAccess dalobj = new DataAccess();
                return dalobj.addJobSeekerDAL(jsObj);
            }
            catch (Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }
    }
}
