﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace RecruitmentDataAccessLayer
{
    public class RecruitmentConfiguration
    {
        private static string connectionString;
        private static string providerName;

        public static string ConnectionString
        {
            get
            {
                return connectionString;
            }

            set
            {
                connectionString = value;
            }
        }

        public static string ProviderName
        {
            get
            {
                return providerName;
            }

            set
            {
                providerName = value;
            }
        }

        static RecruitmentConfiguration()
        {
            connectionString = ConfigurationManager.ConnectionStrings["CMSconString"].ConnectionString;
            providerName = ConfigurationManager.ConnectionStrings["CMSconString"].ProviderName;
        }
    }
}
}
