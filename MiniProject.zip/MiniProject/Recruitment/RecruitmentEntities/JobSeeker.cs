﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecruitmentEntities
{
    class JobSeeker
    {
        public string JS_EMAILID { get; set; }
        public string FIRSTNAME { get; set; }
        public string LASTNAME { get; set; }
        public DateTime DOB { get; set; }
        public long JS_CONTACT { get; set; }
        public string PHOTO { get; set; }
        public string HSC_BOARD { get; set; }
        public string HSC_PERCENTAGE { get; set; }
        public int HSC_YOP { get; set; }
        public string SSC_BOARD { get; set; }
        public string SSC_PERCENTAGE { get; set; }
        public int SSC_YOP { get; set; }
        public string UG_UNIVERSITY { get; set; }
        public int UG_PERCENTAGE { get; set; }
        public int UG_YOP { get; set; }
        public int JS_EXPERIENCE { get; set; }
        public string JS_SKILLS { get; set; }
    }
}
