﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using RecruitmentBusinessAccessLayer;
using RecruitmentEntities;
using RecruitmentExceptions;

namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for JobseekerHomePage.xaml
    /// </summary>
    public partial class JobseekerHomePage : Window
    {
       
        public JobseekerHomePage()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                JobseekerProfile obj = new JobseekerProfile();
                obj.txtEmail.Text = lblWelcome.Content.ToString();
                obj.Show();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void logoutButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            MainWindow obj = new MainWindow();
            obj.Show();
        }

        private void btnSearchJobs_Click(object sender, RoutedEventArgs e)
        {
            string searchText = txtSearch.Text;
            string searchParam = comboParam.Text;

            try
            {
                BussinessRules balObj = new BussinessRules();
                List<Job> jobs = balObj.searchJobs(searchText,searchParam);

                if(jobs!=null)
                {
                    dataGrid.ItemsSource = jobs;
                }
                else
                {
                    throw new RecruitmentException("No jobs found");
                }
            }
            catch(RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            var obj = (Job)dataGrid.SelectedItem;
            MessageBox.Show(obj.JOB_COMPANYNAME.ToString());
        }
    }
}
