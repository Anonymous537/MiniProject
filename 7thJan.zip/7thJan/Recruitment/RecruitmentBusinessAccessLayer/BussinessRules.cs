﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecruitmentDataAccessLayer;
using RecruitmentExceptions;
using RecruitmentEntities;
using System.Text.RegularExpressions;

namespace RecruitmentBusinessAccessLayer
{
    public class BussinessRules
    {
        public string authenticateUser(string username, string password)
        {
            
            DataAccess dalobj = new DataAccess();
            return dalobj.authenticateUserDAL(username, password);
        }

        public bool addUser(string username, string password,string confpassword, string user_type)
        {
            try
            {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();
            if (!Regex.IsMatch(username, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$"))
            {
                sb.Append("Invalid Username. Enter a valid Email Id\n");
                isValid = false;
            }

            if (!Regex.IsMatch(password, @"^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$"))
            {
                sb.Append("Passwords do not meet requirements\n");
                isValid = false;
            }
                if (!password.Equals(confpassword))
                {
                    sb.Append("Passwords do not match\n");
                    isValid = false;
                }

                if (isValid)
            {
                DataAccess dalobj = new DataAccess();
                return dalobj.addUserDAL(username, password, user_type);
            }
            else
            {
                throw new RecruitmentException(sb.ToString());
            }
            
            }

            catch(Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }

        public List<Job> searchJobsByExpBAL(string jsId)
        {
            try
            {
                DataAccess dalObj = new DataAccess();
                return dalObj.searchJobsByExpDAL(jsId);
            }
            catch (Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }

        public string getCompanyName(string email)
        {
            try
            {
                DataAccess dalObj = new DataAccess();
                return dalObj.getcnameDAL(email);
            }
            catch (Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
            
        }
        public bool validateJobSeeker(JobSeeker jsObj)
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();
            if (jsObj.FIRSTNAME == string.Empty)
            {
                sb.Append("Please enter proper first name\n");
                isValid = false;
            }
            if (jsObj.LASTNAME == string.Empty)
            {
                sb.Append("Please enter proper last name\n");
                isValid = false;
            }
            if (jsObj.DOB.Year > 1997)
            {
                sb.Append("Age should be greater than 18\n");
                isValid = false;
            }
            if (!Regex.IsMatch(jsObj.JS_CONTACT.ToString(), @"^[789]\d{9}$"))
            {
                sb.Append("Please enter proper contact number\n");
                isValid = false;
            }
            if (jsObj.SSC_PERCENTAGE <= 0 || jsObj.SSC_PERCENTAGE > 100 || jsObj.HSC_PERCENTAGE <= 0 || jsObj.HSC_PERCENTAGE > 100 || jsObj.UG_PERCENTAGE <= 0 || jsObj.UG_PERCENTAGE > 100)
            {
                sb.Append("Incorrect Percentage\n");
                isValid = false;
            }
            if (jsObj.SSC_YOP <= 2000 || jsObj.SSC_YOP > 2018 || jsObj.HSC_YOP <= 2000 || jsObj.HSC_YOP > 2018 || jsObj.UG_YOP <= 2000 || jsObj.UG_YOP > 2018)
            {
                sb.Append("Incorrect year of passing\n");
                isValid = false;
            }
            if(jsObj.JS_EXPERIENCE<0||jsObj.JS_EXPERIENCE>50)
            {
                sb.Append("Please enter correct years of experience\n");
                isValid = false;
            }
            if (isValid == false)
            {
                throw new RecruitmentException(sb.ToString());
            }
            return isValid;
        }
        public bool addJobSeeker(JobSeeker jsObj)
        {
            try
            {
                bool result = false;
                if(validateJobSeeker(jsObj))
                {
                    DataAccess dalobj = new DataAccess();
                    result =  dalobj.addJobSeekerDAL(jsObj);
                }
                return result;
                
            }
            catch (Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }

        public List<Job> searchJobs(string searchText, string searchParam)
        {
            try
            {
                DataAccess empData = new DataAccess();
                return empData.searchJobsDAL(searchText,searchParam);
            }
            catch (RecruitmentException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool validateJobSeeker(Employer newEmp)
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();
            if (!Regex.IsMatch(newEmp.EMP_CONTACT.ToString(), @"^[789]\d{9}$"))
            {
                sb.Append("Please enter proper contact number\n");
                isValid = false;
            }
            if (!Regex.IsMatch(newEmp.WEBSITE, @"^[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)"))
            {
                sb.Append("Please enter proper company website\n");
                isValid = false;
            }
            if (isValid == false)
            {
                throw new RecruitmentException(sb.ToString());
            }
            return isValid;
        }
        public static bool AddEmployerBL(Employer newEmp)
        {
            bool employerAdded = false;
            try
            {
                DataAccess empData = new DataAccess();
                employerAdded = empData.AddEmployerDAL(newEmp);
            }
            catch (RecruitmentException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employerAdded;
        }

        public List<JobSeeker> searchJSByExp(int jobid)
        {
            try
            {
                DataAccess dalObj = new DataAccess();
                return dalObj.searchJSByExpDAL(jobid);
            }
            catch (RecruitmentException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public int getJobID()
        //{
        //    try
        //    {
        //        DataAccess dalObj = new DataAccess();
        //        return dalObj.getJobIdDAL();
        //    }
        //    catch(Exception ex)
        //    {
        //        throw new RecruitmentException(ex.Message);
        //    }

        //}

        public bool addJob(Job newJob)
        {
            try
            {
                DataAccess dalObj = new DataAccess();
                return dalObj.addJobDAL(newJob);
            }
            catch (Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }
        public Employer GetCompanyDetails(string companyName)
        {
            try
            {
                DataAccess dalObj = new DataAccess();
                return dalObj.GetCompanyDetails(companyName);
            }
            catch (RecruitmentException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public JobSeeker GetSeekerDetails(string email)
        {
            try
            {
                DataAccess dalObj = new DataAccess();
                return dalObj.GetSeekerDetails(email);
            }
            catch (RecruitmentException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<int> getJobIdBAL(string company)
        {
            try
            {
                DataAccess dalObj = new DataAccess();
                return dalObj.getJobIdDAL(company);
            }
            catch (RecruitmentException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /////////////////////////////TO BE USED BY EMPLOYER////////////////////////

        public static List<JobSeeker> SearchJSBLFor(int searchJobID)
        {
            DataAccess dataAccess = new DataAccess();
            JobSeeker jobseeker = new JobSeeker();
            List<JobSeeker> jsList = dataAccess.GetJobseeker();
            string[] jsSkillsTemp = null;
            List<string> jsSkills = null;

            List<string> jobSkills = dataAccess.GetJobSkills(searchJobID);
            //JobseekerDAL jsDAL = new JobseekerDAL();
            List<JobSeeker> matchedJS = new List<JobSeeker>();
            try
            {
                foreach (JobSeeker item in jsList)
                {
                    bool temp;
                    jsSkillsTemp = item.JS_SKILLS.Split(',');
                    jsSkills = new List<string>();
                    jsSkills.AddRange(jsSkillsTemp);
                    jsSkills.Sort();
                    jsSkills.RemoveAt(0);
                    IEnumerable<string> arr = jobSkills.Except(jsSkills);
                    //foreach (string str in arr)
                    //{
                    //    string t;
                    //    t = str;
                    //}
                    if (arr.Count() > 0)
                        temp = true;
                    else
                        temp = false;
                    bool result = (jobSkills.Count <= jsSkills.Count) && !temp;
                    if (result)
                        matchedJS.Add(item);
                }
                return matchedJS;

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /////////////////////////////////TO BE USED BY JOBSEEKER/////////////////////////////

        public static List<Job> SearchJobBLFor(string searchJSID)
        {
            DataAccess dataAccess = new DataAccess();
            Job job = new Job();
            List<Job> jobList = dataAccess.GetAllJobs();
            string[] jobSkillsTemp = null;
            List<string> jobSkills = null;

            List<string> jsSkills = dataAccess.GetJSSkills(searchJSID);
            //JobseekerDAL jsDAL = new JobseekerDAL();
            List<Job> matchedJob = new List<Job>();
            try
            {
                foreach (Job item in jobList)
                {
                    jobSkillsTemp = item.JOB_SKILLS.Split(',');
                    jobSkills = new List<string>();
                    jobSkills.AddRange(jobSkillsTemp);
                    jobSkills.Sort();
                    jobSkills.RemoveAt(0);
                    bool result = (jobSkills.Count <= jsSkills.Count) && !jobSkills.Except(jsSkills).Any();
                    if (result)
                        matchedJob.Add(item);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return matchedJob;
        }
    }
}
