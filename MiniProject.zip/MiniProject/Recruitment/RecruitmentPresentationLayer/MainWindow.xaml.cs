﻿using System.Windows;
using RecruitmentEntities;
using RecruitmentBusinessAccessLayer;
using RecruitmentExceptions;
using System;

namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            BussinessRules balobj = new BussinessRules();
            string username, password;

            try
            {
                username = txtUsername.Text;
                password = txtPassword.Password;
                string type = balobj.authenticateUser(username, password);
            }
            catch(Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
            

        }
    }
}
