﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using RecruitmentBusinessAccessLayer;
using RecruitmentEntities;
using RecruitmentExceptions;

namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for JobseekerHomePage.xaml
    /// </summary>
    public partial class JobseekerHomePage : Window
    {
       
        public JobseekerHomePage()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                JobseekerProfile obj = new JobseekerProfile();
                obj.txtEmail.Text = lblWelcome.Content.ToString();
                obj.Show();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void logoutButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            MainWindow obj = new MainWindow();
            obj.Show();
        }

        private void btnSearchJobs_Click(object sender, RoutedEventArgs e)
        {
            string searchText = txtSearch.Text;
            string searchParam = comboParam.Text;

            if (searchParam == "Location" || searchParam == "Designation")
            {
                BussinessRules balObj = new BussinessRules();
                List<Job> jobs = balObj.searchJobs(searchText, searchParam);

                if (jobs != null)
                {
                    dataGrid.ItemsSource = jobs;
                }
                else
                {
                    throw new RecruitmentException("No jobs found");
                }
            }
            if (searchParam == "SkillSet")
            {
                try
                {
                    string jsID = lblWelcome.Content.ToString();
                    string str = "";
                    List<Job> jobList = BussinessRules.SearchJobBLFor(jsID);
                    dataGrid.ItemsSource = jobList;
                    foreach (Job item in jobList)
                    {
                        str = str + "\n" + item.JOBID;
                    }
                    MessageBox.Show(str);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            if (searchParam == "Experience")
            {
                try
                {
                    BussinessRules balObj = new BussinessRules();
                    string jsID = lblWelcome.Content.ToString();
                    
                    List<Job> jobList = balObj.searchJobsByExpBAL(jsID);
                    dataGrid.ItemsSource = jobList;
                   
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            var obj = (Job)dataGrid.SelectedItem;
            ViewCompanyProfile Companyobj = new ViewCompanyProfile();
            BussinessRules balobj = new BussinessRules();
            Employer emp = balobj.GetCompanyDetails(obj.JOB_COMPANYNAME);
            //Companyobj.labelcompanyname.Content = emp.EMP_EMAILID;
            Companyobj.labelcompanyname.Content = emp.EMP_COMPANYNAME;
            Companyobj.txtabout.Text = emp.COMPANYINFO;
            //Companyobj.labelabout.Content = emp.COMPANYINFO;
            Companyobj.labelclient.Content = emp.CLIENT;
            Companyobj.labelcontact.Content = emp.EMP_CONTACT;
            Companyobj.labelwebsite.Content = emp.WEBSITE;

            Companyobj.Show();
            

            //MessageBox.Show(obj.JOB_COMPANYNAME.ToString());
        }

        private void ListBoxItem_Selected(object sender, RoutedEventArgs e)
        {
            ViewCompanyProfile Companyobj = new ViewCompanyProfile();
            string cname = "Capgemini";
            BussinessRules balobj = new BussinessRules();
            Employer emp = balobj.GetCompanyDetails(cname);
            //Companyobj.labelcompanyname.Content = emp.EMP_EMAILID;
            Companyobj.labelcompanyname.Content = emp.EMP_COMPANYNAME;
            Companyobj.txtabout.Text = emp.COMPANYINFO;
            //Companyobj.labelabout.Content = emp.COMPANYINFO;
            Companyobj.labelclient.Content = emp.CLIENT;
            Companyobj.labelcontact.Content = emp.EMP_CONTACT;
            Companyobj.labelwebsite.Content = emp.WEBSITE;

            Companyobj.Show();
        }

        private void ListBoxItem_Selected_1(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
