﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using RecruitmentBusinessAccessLayer;
using RecruitmentExceptions;

namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for EmployerHomePage.xaml
    /// </summary>
    public partial class EmployerHomePage : Window
    {
        public EmployerHomePage()
        {
            InitializeComponent();
            
        }

        private void btnAddJob_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                JobDetails jdObj = new JobDetails();
                
                jdObj.txtCompanyName.Text = lblcompany.Content.ToString();
                jdObj.Show();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEditProf_Click(object sender, RoutedEventArgs e)
        {
            EmployerProfile obj = new EmployerProfile();
            obj.txtEmailId.Text = label.Content.ToString();
            obj.Show();
            //this.Close();
        }
    }
}
