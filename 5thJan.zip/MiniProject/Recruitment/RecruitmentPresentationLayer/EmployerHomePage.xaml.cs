﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using RecruitmentBusinessAccessLayer;
using RecruitmentExceptions;
using RecruitmentEntities;

namespace RecruitmentPresentationLayer
{
    /// <summary>
    /// Interaction logic for EmployerHomePage.xaml
    /// </summary>
    public partial class EmployerHomePage : Window
    {
        public EmployerHomePage()
        {
            InitializeComponent();
            
        }

        private void btnAddJob_Click(object sender, RoutedEventArgs e)
        {
            string cname = "";
            string email = lblcompany.Content.ToString();
            try
            {
                JobDetails jdObj = new JobDetails();
                BussinessRules balObj = new BussinessRules();
                    cname = balObj.getCompanyName(email);
                    if (cname != null)
                    jdObj.txtCompanyName.Text = cname;
                    else
                        throw new RecruitmentException("Couldn't retrieve company name");
               
                jdObj.Show();
            }
            catch (RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEditProf_Click(object sender, RoutedEventArgs e)
        {
            EmployerProfile obj = new EmployerProfile();
            obj.txtEmailId.Text = lblcompany.Content.ToString();
            obj.Show();
            //this.Close();
        }

        private void logoutButton_Click(object sender, RoutedEventArgs e)
        {
            GenericHomePage obj = new GenericHomePage();
            obj.Show();
            this.Close();
            
        }


        private void btnSearchJobs_Click_1(object sender, RoutedEventArgs e)
        {
            string searchText = txtSearch.Text;
            string searchParam = comboParam.Text;

            try
            {
                BussinessRules balObj = new BussinessRules();
                List<JobSeeker> seekerList = balObj.searchJobseeker(searchText, searchParam);

                if (seekerList != null)
                {
                    
                    dataGrid.ItemsSource = seekerList;
                    for (int i = 3; i < 15; i++)
                    {
                        dataGrid.Columns[i].Visibility = Visibility.Collapsed;
                    }
                    dataGrid.Columns[17].Visibility = Visibility.Collapsed;

                }
                else
                {
                    throw new RecruitmentException("No jobseekers found");
                }
            }
            catch (RecruitmentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
