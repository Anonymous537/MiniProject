﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecruitmentExceptions;
using RecruitmentEntities;
using System.Data.Common;
using System.Data;

namespace RecruitmentDataAccessLayer
{
    public class DataAccess
    {
        public string authenticateUserDAL(string username, string password)
        {
            DbCommand command = DataConnection.CreateCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = "select user_type from Login_Credentials";

            DataTable dt = DataConnection.ExecuteSelectCommand(command);
            if(dt.Rows.Count > 0)
            {

            }
        }
    }
}
