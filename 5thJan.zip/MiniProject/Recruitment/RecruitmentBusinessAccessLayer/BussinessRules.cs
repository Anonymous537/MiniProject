﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RecruitmentDataAccessLayer;
using RecruitmentExceptions;
using RecruitmentEntities;

namespace RecruitmentBusinessAccessLayer
{
    public class BussinessRules
    {
        public string authenticateUser(string username, string password)
        {
            DataAccess dalobj = new DataAccess();
            return dalobj.authenticateUserDAL(username, password);

        }

        public bool addUser(string username, string password, string user_type)
        {
            try
            {
                DataAccess dalobj = new DataAccess();
                return dalobj.addUserDAL(username, password, user_type);
            }
            catch(Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }

        public string getCompanyName(string email)
        {
            try
            {
                DataAccess dalObj = new DataAccess();
                return dalObj.getcnameDAL(email);
            }
            catch (Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
            
        }

        public bool addJobSeeker(JobSeeker jsObj)
        {
            try
            {
                DataAccess dalobj = new DataAccess();
                return dalobj.addJobSeekerDAL(jsObj);
            }
            catch (Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }

        public List<Job> searchJobs(string searchText, string searchParam)
        {
            try
            {
                DataAccess empData = new DataAccess();
                return empData.searchJobsDAL(searchText,searchParam);
            }
            catch (RecruitmentException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool AddEmployerBL(Employer newEmp)
        {
            bool employerAdded = false;
            try
            {
                DataAccess empData = new DataAccess();
                employerAdded = empData.AddEmployerDAL(newEmp);
            }
            catch (RecruitmentException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employerAdded;
        }

        public List<JobSeeker> searchJobseeker(string searchText, string searchParam)
        {
            try
            {
                DataAccess dalObj = new DataAccess();
                return dalObj.searchJobseekerDAL(searchText, searchParam);
            }
            catch (RecruitmentException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public int getJobID()
        //{
        //    try
        //    {
        //        DataAccess dalObj = new DataAccess();
        //        return dalObj.getJobIdDAL();
        //    }
        //    catch(Exception ex)
        //    {
        //        throw new RecruitmentException(ex.Message);
        //    }

        //}

        public bool addJob(Job newJob)
        {
            try
            {
                DataAccess dalObj = new DataAccess();
                return dalObj.addJobDAL(newJob);
            }
            catch (Exception ex)
            {
                throw new RecruitmentException(ex.Message);
            }
        }
    }
}
