﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecruitmentDataAccessLayer
{
    class DataConnection
    {
        public static DbCommand CreateCommand()
        {
            string dataProviderName = RecruitmentConfiguration.ProviderName;
            string connectionString = RecruitmentConfiguration.ConnectionString;

            DbProviderFactory factory = DbProviderFactories.GetFactory(dataProviderName);
            DbConnection conn = factory.CreateConnection();

            conn.ConnectionString = connectionString;

            DbCommand comm = conn.CreateCommand();
            comm.CommandType = CommandType.StoredProcedure;

            return comm;
        }

        public static DataTable ExecuteSelectCommand(DbCommand command)
        {
            //The Datatable to be returned
            DataTable dataTable = null;
            //Execute the command making sure the connection gets closed in the end
            try
            {
                //open the connection
                command.Connection.Open();
                //Execute the Command and store the results in a datatable
                DbDataReader dataReader = command.ExecuteReader();
                dataTable = new DataTable();
                dataTable.Load(dataReader);
                //Close the reader
                dataReader.Close();
            }
            catch (DbException ex)
            {
                throw ex;
            }
            finally
            {
                //Close the Connection
                if (command.Connection.State == ConnectionState.Open)
                    command.Connection.Close();
            }
            return dataTable;
        }
        public static int ExecuteNonQueryCommand(DbCommand command)
        {
            // The number of affected rows 
            int affectedRows = -1;
            // Execute the command making sure the connection gets closed in the end
            try
            {
                // Open the connection of the command
                command.Connection.Open();
                // Execute the command and get the number of affected rows
                affectedRows = command.ExecuteNonQuery();
            }
            catch (DbException ex)
            {
                throw ex;
            }
            finally
            {
                //Close the Connection
                if (command.Connection.State == ConnectionState.Open)
                    command.Connection.Close();
            }
            // return the number of affected rows
            return affectedRows;
        }

        public static object ExecuteScalarCommand(DbCommand command)
        {

            // The value to be returned 
            object result = null;
            // Execute the command making sure the connection gets closed in the end
            try
            {
                // Open the connection of the command
                command.Connection.Open();
                // Execute the command and get the aggregate value
                result = command.ExecuteScalar();
            }
            catch (DbException ex)
            {
                throw ex;
            }

            finally
            {
                //Close the Connection
                if (command.Connection.State == ConnectionState.Open)
                    command.Connection.Close();
            }
            // return the result
            return result;
        }
    }
}
